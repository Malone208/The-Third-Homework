# HW3-姜佳岩：四副本 Ray Serve 路由实验

## 正式结果

正式对照采用 2026-10-07 在 AutoDL 重庆 A 区 133 机完成的 **run-2**。五轮使用同一台四卡服务器、同一组五个 Ray 节点和同一课程负载。每轮 64 条预热、2048 条测量全部成功返回。B 按预定规则选出 32；C 的 64 个前缀族通过严格亲和核验。

| 报告行 | 原始结果目录（相对于项目根目录） | 路由 / 容量 |
| --- | --- | --- |
| A | results/target3/A_default/run-2/ | 默认 P2C / 5 |
| B16 | results/target3/B_candidates/candidate-16/run-2/ | P2C / 16 |
| B32（选定） | results/target3/B_candidates/candidate-32/run-2/ | P2C / 32 |
| C | results/target3/C_affinity/run-2/ | 原生 ConsistentHashRouter / 32 |
| D | results/target3/D_improved/run-2/ | AffinityLoadRouter / 32 |

各目录保留 requests.csv、warmups.csv、summary.json、config.json、deployment.json、routing_preflight.json 与四个副本的节点/后端映射。C 另有 strict_affinity_check.json。正式参数选择为 `B_candidates/selection-run-2.json`，总对照为 `results/target3/comparison-run-2.json`。

**run-1 是旧服务器 165 机上的历史试运行，不与 run-2 混合汇总。** 当时重复使用同一 Serve 应用标识，代理缓存的路由实例没有正确替换，原 C/D 亲和没有实际生效。发现后修复部署标识，加入路由预检与 C 全量核验，并在新 133 机完整重跑五组。保留旧 CSV/JSON、旧 selection.json（16）、旧 comparison.json 与 `.before-*` 备份用于追溯，均不用于正式结论。

目标一代码和结果来自已完成的第二次作业，目录为 `src/target1/` 与 `results/target1/{shared_prefix,dispersed_prefix}/`，环境是本地 WSL Ubuntu 24 / RTX 4060 Laptop 8 GB，未在本次云服务器重跑，不参与目标三比较。

## 硬件与软件

同一物理服务器：4 × NVIDIA GeForce RTX 4090 D，每卡 24 GB；实例 64 CPU 核、320 GB 内存。Ubuntu 22.04.5 LTS、Python 3.12.3、NVIDIA 驱动 580.76.05、CUDA Toolkit 13.0.88、SGLang 0.5.14、Ray 2.56.0、PyTorch 2.11.0+cu130、protobuf 6.33.6、grpcio 1.84.0、grpcio-reflection / grpcio-health-checking 1.78.0。

模型为 Qwen/Qwen3-0.6B（ModelScope）。四个 SGLang 进程分别使用四张卡，相同 context-length=4096、mem-fraction-static=0.6、stream-interval=1，启用 Radix Cache；端口 31000 至 31003。Ray 仅转发，num_gpus=0 不代表模型用 CPU。

实际环境证据在 `runtime/*-run-2.txt`。cluster.json 与每轮 deployment.json 是实验时的历史状态，不能据此判断实例目前仍在运行。

## 安装：Linux 四卡服务器

将提交包解压到数据盘，进入项目目录。需要 Python 3.12、四张可用 NVIDIA GPU、支持 CUDA 13 组件的驱动及工具链。

```bash
cd "/root/autodl-tmp/HW3-姜佳岩"
python --version
nvidia-smi
nvcc --version
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r src/target3/requirements.txt
python -m pip check
python -c "import torch; print(torch.__version__, torch.version.cuda, torch.cuda.is_available(), torch.cuda.device_count())"
python src/target3/test_policy.py
python src/target3/course/validate_workload.py src/target3/course/mooncake_prefix_workload_v2_seed2026.jsonl
```

requirements.txt 固定关键版本；完整实际版本见 runtime/pip-freeze-run-2.txt。

## 启动与重跑

终端一：

```bash
cd "/root/autodl-tmp/HW3-姜佳岩"
source .venv/bin/activate
python src/target3/start_services.py
```

脚本下载模型、启动四个后端，建立 1 head + 4 worker。每个 worker 有一单位 `hw3_worker` 自定义资源，每个 Replica 需要一单位，保证四副本分别位于四 worker；每副本按节点绑定一个后端。head 运行 HTTP Proxy。保持终端一运行。已有模型可加 `--model-path /实际模型目录`；默认使用实例分配的 CUDA_VISIBLE_DEVICES，必要时加 `--gpu-ids 0,1,2,3`。

终端二：**用全新的 run-3，避免覆盖提交包已有 run-1/run-2**。如 run-3 已存在，将下面所有轮次一致改为新编号。逐条执行，上一条成功后再执行下一条。

```bash
cd "/root/autodl-tmp/HW3-姜佳岩"
source .venv/bin/activate
python src/target3/run_round.py --group A --run-name run-3
python src/target3/run_round.py --group B --limit 16 --run-name run-3
python src/target3/run_round.py --group B --limit 32 --run-name run-3
python src/target3/select_b.py run-3
python src/target3/run_round.py --group C --run-name run-3
python src/target3/run_round.py --group D --run-name run-3
```

入口固定 `http://127.0.0.1:8000/generate`。每轮阻塞删除旧应用，以包含组别/容量/轮次的新应用名部署，核验四副本/四节点/四后端映射，完成 12 条诊断请求，再清空四缓存，执行课程 64 条预热和 2048 条测量。诊断不计入正式结果。客户端 max-in-flight=2048、timeout=300 s、temperature=0、ignore_eos=true、seed=2026，保持发布的请求内容、顺序、到达时间。

C/D 自动读取本轮 selection-run-3.json，保持与 B 选定容量一致。C 还在含预热的全部 CSV 上检查每个前缀族只访问一个后端。非空结果目录会报错，不覆盖旧结果。

比较新一轮：

```bash
python src/target3/course/compare_runs.py --baseline A --run A=results/target3/A_default/run-3/summary.json --run B16=results/target3/B_candidates/candidate-16/run-3/summary.json --run B32=results/target3/B_candidates/candidate-32/run-3/summary.json --run C=results/target3/C_affinity/run-3/summary.json --run D=results/target3/D_improved/run-3/summary.json --output results/target3/comparison-run-3.json
```

只核对提交包数据，无需 GPU：

```bash
python src/target3/audit_submission.py
```

确认结果保存后，在终端一按 Ctrl+C 清理服务，在云平台控制台关闭实例。关闭本地电脑不能代替关闭云实例。

## 路由规则、指标与限制

B：吞吐量距最好候选不超过 5% 的候选中，选 TTFT p95 最低者，再以 E2E p95、更小容量打破平局。run-2 两个候选均入围，B32 的 TTFT p95 更小，因此选 32。

C：原生 ConsistentHashRouter，100 虚拟节点、num_fallback_replicas=0、X-Session-Id=prefix_family。D：主副本已知队列达到容量 75%（容量 32 时为 24），且比已知较空副本至少多 2 个请求、对方未满时溢出；否则保持亲和。只读当前请求与当前队列缓存，未知/过期负载不视作 0，不读取未来请求。缓存估计可能滞后，溢出会增加重复 Prefill。

吞吐量=成功测量请求数/测量开始至全部请求结束的时长（含排空）；缓存命中率=总 cached_tokens/总 prompt_tokens；实际 Prefill token=prompt_tokens-cached_tokens。TTFT 是客户端首 token 延迟，E2E 是完整请求延迟；p95 使用课程 nearest-rank。Prefill 是接口报告的 token 数，不是直接测得的 GPU FLOPs。预热不计入主表。

每轮重部署产生新 Replica ID，一致哈希的具体映射可能变化。本次每配置只有一轮正式结果，不报告置信区间，不把旧服务器试运行与正式结果平均。D 不要求全部指标最优。

## 脚本用途与来源

| 文件（src/target3/ 下） | 用途 |
| --- | --- |
| start_services.py | 四 SGLang 后端、五 Ray 节点、Ctrl+C 清理 |
| forwarder.py | 固定后端转发、SSE、路由响应标识 |
| run_round.py | 配置部署、预检、清缓存、正式回放 |
| route_preflight.py | 会话预检与 C 全量亲和核验 |
| select_b.py | 本轮两个 B 候选选择 |
| improved_router.py、policy.py | D 的亲和与当前负载规则 |
| test_policy.py | D 的离线边界规则测试 |
| audit_submission.py | CSV、汇总、拓扑、固定负载核验 |
| export_results.py | 本次云端 run-2 专用导出，非 run-3 通用导出器 |
| course/ | 课程原始回放、校验、汇总脚本及负载说明 |

课程仓库：[Zirkland/26fall-HW-data](https://github.com/Zirkland/26fall-HW-data)，固定提交 `9651052e597def42d5ee22548d904d8927365b20`。
负载 SHA256：`f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03`。
原生路由：[Ray 2.56.0 源码](https://github.com/ray-project/ray/blob/ray-2.56.0/python/ray/serve/experimental/consistent_hash_router.py)。

报告数字对应五轮 summary.json；`results/target3/report_main_table.csv` 是便于阅读的提取表；`runtime/submission_provenance.json` 记录来源与正式轮次；`runtime/submission_audit.json` 保存追加核验。模型权重、环境、安装包、缓存均未提交。
