"""Verify HTTP session propagation and low-load affinity before cache flush."""
import csv
import json
from collections import defaultdict
from pathlib import Path
from urllib.request import Request, urlopen


def run_preflight(output, group):
    checks = []
    for family in ('hw3-affinity-probe-a', 'hw3-affinity-probe-b'):
        for index in range(6):
            payload = {'input_ids': [4096] * 8,
                       'sampling_params': {'max_new_tokens': 1, 'temperature': 0,
                                           'ignore_eos': True}, 'stream': False}
            request = Request('http://127.0.0.1:8000/generate',
                              data=json.dumps(payload).encode(), method='POST',
                              headers={'Content-Type': 'application/json',
                                       'X-Session-Id': family,
                                       'X-Prefix-Family': family})
            with urlopen(request, timeout=60) as response:
                response.read()  # Drain every response before probing again.
                checks.append({'session': family, 'index': index,
                               'status': response.status,
                               'backend': response.headers.get('X-SGLang-Backend', ''),
                               'serve_session': response.headers.get('X-Serve-Session-ID', '')})
    errors = []
    for item in checks:
        if item['status'] != 200 or not item['backend']:
            errors.append('Missing backend or unsuccessful response')
        if item['serve_session'] != item['session']:
            errors.append('HTTP session header did not reach Serve request metadata')
    if group in ('C', 'D'):
        for family in ('hw3-affinity-probe-a', 'hw3-affinity-probe-b'):
            if len({x['backend'] for x in checks if x['session'] == family}) != 1:
                errors.append('Same-session sequential requests reached multiple backends')
    result = {'group': group, 'passed': not errors, 'errors': sorted(set(errors)),
              'note': 'Diagnostic only; all four caches are flushed after this probe. '
                      'These requests do not enter official warmups or measurements.',
              'responses': checks}
    (Path(output) / 'routing_preflight.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    if errors:
        raise RuntimeError('Routing preflight failed: ' + '; '.join(result['errors']))


def verify_strict_affinity(output):
    families = defaultdict(set)
    for name in ('warmups.csv', 'requests.csv'):
        with (Path(output) / name).open(encoding='utf-8', newline='') as handle:
            for row in csv.DictReader(handle):
                families[row['prefix_family']].add(row['backend'])
    violations = {key: sorted(value) for key, value in families.items() if len(value) != 1}
    result = {'passed': len(families) == 64 and not violations,
              'families': len(families), 'violations': violations,
              'family_backend': {key: sorted(value) for key, value in families.items()}}
    (Path(output) / 'strict_affinity_check.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    if not result['passed']:
        raise RuntimeError('C strict affinity failed; preserve this run as invalid')
