"""Fetch the published workload at an immutable course commit; verify before saving."""
import hashlib
from pathlib import Path
from urllib.request import urlopen

COMMIT = '9651052e597def42d5ee22548d904d8927365b20'
SHA256 = 'f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03'
NAME = 'mooncake_prefix_workload_v2_seed2026.jsonl'
TARGET = Path(__file__).resolve().parent / 'course' / NAME
URL = f'https://raw.githubusercontent.com/Zirkland/26fall-HW-data/{COMMIT}/workloads/hw2/target3-routing-policies/{NAME}'


def main():
    data = TARGET.read_bytes() if TARGET.exists() else urlopen(URL, timeout=120).read()
    digest = hashlib.sha256(data).hexdigest()
    if digest != SHA256:
        raise ValueError(f'Workload checksum mismatch: {digest}; do not use this file')
    if not TARGET.exists():
        TARGET.write_bytes(data)
    print('Fixed workload verified:', digest)


if __name__ == '__main__':
    main()
