"""Choose B from two valid runs using a declared throughput/TTFT rule."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]


def main():
    run_name = sys.argv[1] if len(sys.argv) > 1 else 'run-1'
    folder = ROOT / 'results/target3/B_candidates'
    items = []
    for limit in (16, 32):
        path = folder / f'candidate-{limit}' / run_name / 'summary.json'
        data = json.loads(path.read_text('utf-8'))
        if (data['successful'] != 2048 or data['failed'] or data['incomplete']
                or data['validation_errors'] or data['warmup_successful'] != 64
                or data['max_ongoing_requests'] != limit):
            raise ValueError('Candidate failed validation: ' + str(path))
        items.append({'limit': limit, 'throughput_rps': data['throughput_rps'],
                      'ttft_p95_s': data['ttft_s']['p95'],
                      'latency_p95_s': data['latency_s']['p95'],
                      'summary': str(path.relative_to(ROOT))})
    fast = max(items, key=lambda x: x['throughput_rps'])
    near = [x for x in items if x['throughput_rps'] >= fast['throughput_rps'] * 0.95]
    selected = min(near, key=lambda x: (x['ttft_p95_s'], x['latency_p95_s'], x['limit']))
    choice = {'selected_limit': selected['limit'], 'candidates': items,
              'rule': 'Within 5% of the higher throughput, choose smaller TTFT p95; '
                      'then smaller E2E p95, then smaller request limit.'}
    target = folder / ('selection.json' if run_name == 'run-1'
                       else f'selection-{run_name}.json')
    if target.exists():
        raise FileExistsError('B selection already saved; preserve it before a new experiment series')
    target.write_text(json.dumps(choice, indent=2), encoding='utf-8')
    print(json.dumps(choice, indent=2))


if __name__ == '__main__':
    main()
