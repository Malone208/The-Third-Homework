"""Linux: own four SGLang process groups and a head + four local Ray nodes."""
import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from urllib.request import urlopen

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STATE = ROOT / 'runtime' / 'cluster.json'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model-path', help='Existing local Qwen3-0.6B model directory')
    parser.add_argument('--gpu-ids', help='Four allocated CUDA device IDs/UUIDs, comma-separated')
    args = parser.parse_args()
    if sys.platform != 'linux':
        raise RuntimeError('Run on the rented Linux server')
    import ray
    import torch
    from ray import serve
    from ray.cluster_utils import Cluster

    versions = {name: importlib.metadata.version(name) for name in ('sglang', 'ray', 'torch')}
    if versions['sglang'] != '0.5.14' or versions['ray'] != '2.56.0':
        raise RuntimeError('Required software versions not installed: ' + str(versions))
    if not torch.cuda.is_available() or torch.cuda.device_count() < 4:
        raise RuntimeError('Four visible CUDA GPUs are required')
    allocated = args.gpu_ids or os.environ.get('CUDA_VISIBLE_DEVICES') or '0,1,2,3'
    gpu_ids = [value.strip() for value in allocated.split(',')]
    if len(gpu_ids) != 4 or len(set(gpu_ids)) != 4:
        raise ValueError('Select exactly four distinct allocated devices')
    model_path = args.model_path
    if not model_path:
        from modelscope import snapshot_download
        model_path = snapshot_download('Qwen/Qwen3-0.6B')

    STATE.parent.mkdir(parents=True, exist_ok=True)
    logs = STATE.parent / 'logs'
    logs.mkdir(exist_ok=True)
    # Propagate import paths to the local Ray nodes without uploading weights/caches.
    os.environ['PYTHONPATH'] = str(HERE) + os.pathsep + os.environ.get('PYTHONPATH', '')
    processes, handles, cluster = [], [], None
    urls = [f'http://127.0.0.1:{31000 + i}' for i in range(4)]
    stopped = False

    def stop(signum, frame):
        nonlocal stopped
        stopped = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        for i, device in enumerate(gpu_ids):
            env = os.environ.copy()
            env.update(CUDA_VISIBLE_DEVICES=device, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
            handle = (logs / f'sglang-{i}.log').open('a', encoding='utf-8')
            handles.append(handle)
            command = [sys.executable, '-m', 'sglang.launch_server',
                       '--model-path', str(model_path), '--host', '127.0.0.1',
                       '--port', str(31000 + i), '--context-length', '4096',
                       '--mem-fraction-static', '0.6', '--stream-interval', '1']
            processes.append(subprocess.Popen(command, env=env, stdout=handle,
                                               stderr=subprocess.STDOUT, start_new_session=True))
        ready = set()
        deadline = time.monotonic() + 900
        while len(ready) != 4:
            if stopped:
                return
            for i, proc in enumerate(processes):
                if proc.poll() is not None:
                    raise RuntimeError(f'SGLang backend {i} stopped; inspect {logs}/sglang-{i}.log')
                if i in ready:
                    continue
                try:
                    with urlopen(urls[i] + '/health', timeout=2) as response:
                        if response.status == 200:
                            ready.add(i)
                            print(f'Backend {i} ready', flush=True)
                except OSError:
                    pass
            if time.monotonic() > deadline:
                raise TimeoutError('SGLang startup timed out; inspect backend logs')
            time.sleep(1)

        node_ip = ray.util.get_node_ip_address()
        print('Ray node IP:', node_ip, flush=True)
        cluster = Cluster(shutdown_at_exit=True)
        cluster.add_node(num_cpus=2, num_gpus=0, resources={'hw3_head': 1},
                         include_dashboard=False, node_ip_address=node_ip)
        for i in range(4):
            cluster.add_node(num_cpus=2, num_gpus=0,
                             resources={'hw3_worker': 1, f'hw3_backend_{i}': 1},
                             node_ip_address=node_ip)
        cluster.wait_for_nodes(timeout=120)
        ray.init(address=cluster.address, namespace='hw3', log_to_driver=True)
        nodes = [n for n in ray.nodes() if n['Alive']]
        if len(nodes) != 5:
            raise RuntimeError('Expected five active Ray nodes')
        by_node = {}
        for i in range(4):
            matches = [n for n in nodes if n['Resources'].get(f'hw3_backend_{i}') == 1]
            if len(matches) != 1:
                raise RuntimeError('Worker marker resources are not unique')
            by_node[matches[0]['NodeID']] = urls[i]
        state = {'address': cluster.address, 'backend_by_node': by_node,
                 'nodes': nodes, 'versions': versions, 'cuda_runtime': torch.version.cuda,
                 'gpu_ids': gpu_ids, 'gpu_name': torch.cuda.get_device_name(0),
                 'model_path': str(model_path), 'ready': True,
                 'sglang_options': {'context_length': 4096, 'mem_fraction_static': 0.6,
                                    'stream_interval': 1, 'radix_cache_disabled': False}}
        STATE.write_text(json.dumps(state, indent=2), encoding='utf-8')
        print('Four backends and five Ray nodes ready. Keep this terminal running.', flush=True)
        print('Cluster state:', STATE, flush=True)
        while not stopped:
            if any(p.poll() is not None for p in processes):
                raise RuntimeError('A backend exited during the experiment')
            time.sleep(1)
    finally:
        if cluster is not None:
            try:
                if ray.is_initialized():
                    try:
                        serve.shutdown()
                    finally:
                        ray.shutdown()
                cluster.shutdown()
            except Exception as exc:
                print('Ray cleanup failed:', exc, file=sys.stderr)
        for proc in processes:
            if proc.poll() is None:
                # Only process groups created by this launcher are signalled.
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        for proc in processes:
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
        for handle in handles:
            handle.close()
        if STATE.exists():
            state = json.loads(STATE.read_text('utf-8'))
            state['ready'] = False
            STATE.write_text(json.dumps(state, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
