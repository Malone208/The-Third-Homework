"""D: extend the pinned Ray 2.56.0 consistent-hash router."""
from ray.serve.experimental.consistent_hash_router import ConsistentHashRouter
from policy import rank_replicas


class AffinityLoadRouter(ConsistentHashRouter):
    def initialize_state(self, **kwargs):
        self.load_fraction = float(kwargs.pop("load_fraction", 0.75))
        self.load_gap = int(kwargs.pop("load_gap", 2))
        kwargs["num_fallback_replicas"] = 0
        super().initialize_state(**kwargs)

    async def choose_replicas(self, candidate_replicas, pending_request=None):
        affinity_ranks = await super().choose_replicas(candidate_replicas, pending_request)
        if not affinity_ranks or not affinity_ranks[0] or pending_request is None:
            return affinity_ranks
        primary = affinity_ranks[0][0]
        replicas = {r.replica_id: r for r in candidate_replicas}
        loads = {rid: self.replica_queue_len_cache.get(rid) for rid in replicas}
        ranks = rank_replicas(
            list(replicas), primary.replica_id, loads,
            primary.max_ongoing_requests, self.load_fraction, self.load_gap,
        )
        return [[replicas[rid] for rid in rank] for rank in ranks]
