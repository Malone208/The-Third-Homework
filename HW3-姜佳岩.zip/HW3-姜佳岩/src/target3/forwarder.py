"""Each Serve replica is pinned by a one-unit worker resource to one logical node."""
import json
from pathlib import Path
import aiohttp
import ray
from ray import serve
from ray.serve.context import _get_serve_request_context
from starlette.responses import JSONResponse, StreamingResponse


@serve.deployment
class SGLangForwarder:
    def __init__(self, backend_by_node, topology_dir):
        self.node_id = ray.get_runtime_context().get_node_id()
        self.replica_id = str(serve.get_replica_context().replica_id)
        if self.node_id not in backend_by_node:
            raise RuntimeError("Replica started outside the four worker nodes")
        self.backend = backend_by_node[self.node_id]
        self.client = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(
            total=None, connect=15, sock_read=600))
        path = Path(topology_dir)
        path.mkdir(parents=True, exist_ok=True)
        # There is exactly one replica per worker, so each writes its own file.
        (path / (self.node_id + '.json')).write_text(json.dumps({
            'replica_id': self.replica_id, 'ray_node_id': self.node_id,
            'backend': self.backend,
        }, indent=2), encoding='utf-8')

    async def __call__(self, request):
        if request.method != 'POST' or request.url.path != '/generate':
            return JSONResponse({'error': 'Use POST /generate'}, status_code=404)
        headers = {'Content-Type': 'application/json'}
        for name in ('X-Session-Id', 'X-Workload-Request-ID', 'X-Prefix-Family'):
            if name in request.headers:
                headers[name] = request.headers[name]
        response = await self.client.post(
            self.backend + '/generate', data=await request.body(), headers=headers)

        async def relay():
            try:
                async for chunk in response.content.iter_any():
                    yield chunk
            finally:
                response.close()

        return StreamingResponse(relay(), status_code=response.status, headers={
            'Content-Type': response.headers.get('Content-Type', 'text/event-stream'),
            'Cache-Control': 'no-cache',
            'X-Ray-Replica-ID': self.replica_id,
            'X-Ray-Node-ID': self.node_id,
            'X-SGLang-Backend': self.backend,
            'X-Serve-Session-ID': _get_serve_request_context().session_id,
        })
