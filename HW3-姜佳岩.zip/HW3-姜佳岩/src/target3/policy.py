"""Pure decision rule used by the D router; no future workload is available here."""
import math


def rank_replicas(ids, primary, queue_lengths, capacity, fraction=0.75, gap=2):
    """Keep affinity unless primary load is high and another known load is lower.

    Unknown/stale queue lengths do not count as zero. When affinity is kept,
    the framework probes/retries the primary. On spillover, known least-loaded
    replicas are preferred; remaining candidates are fallback ranks.
    """
    ids = list(ids)
    if not ids:
        return []
    if primary not in ids:
        return [ids]
    if capacity <= 0 or not 0 < fraction <= 1 or gap < 0:
        raise ValueError("Invalid routing thresholds")
    primary_load = queue_lengths.get(primary)
    alternatives = [i for i in ids if i != primary and queue_lengths.get(i) is not None]
    if primary_load is None or not alternatives:
        return [[primary]]
    best = min(alternatives, key=lambda i: (queue_lengths[i], str(i)))
    if (primary_load < math.ceil(capacity * fraction)
            or primary_load - queue_lengths[best] < gap
            or queue_lengths[best] >= capacity):
        return [[primary]]
    ranked = sorted(alternatives, key=lambda i: (queue_lengths[i], str(i)))
    ranked += [i for i in ids if i not in ranked and i != primary]
    return [[i] for i in ranked] + [[primary]]
