"""Validate run-2, capture runtime evidence, and export without environments or weights."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
RUNS = {
    'A': 'A_default',
    'B1': 'B_candidates/candidate-16',
    'B2': 'B_candidates/candidate-32',
    'C': 'C_affinity',
    'D': 'D_improved',
}


def main():
    runtime = ROOT / 'runtime'
    runtime.mkdir(exist_ok=True)
    for name, folder in RUNS.items():
        path = ROOT / 'results/target3' / folder / 'run-2'
        summary = json.loads((path / 'summary.json').read_text('utf-8'))
        assert summary['requests'] == summary['successful'] == 2048, name
        assert summary['failed'] == summary['incomplete'] == 0, name
        assert summary['warmup_successful'] == 64, name
        assert summary['warmup_failed'] == summary['warmup_incomplete'] == 0, name
        assert not summary['validation_errors'], name
        assert len(summary['backend_distribution']) == 4, name
        probe = json.loads((path / 'routing_preflight.json').read_text('utf-8'))
        assert probe['passed'], name
    strict = ROOT / 'results/target3/C_affinity/run-2/strict_affinity_check.json'
    assert json.loads(strict.read_text('utf-8'))['passed'], 'C affinity check'
    command = [sys.executable, str(ROOT / 'src/target3/course/compare_runs.py'),
               '--baseline', 'A']
    for name, folder in RUNS.items():
        command.extend(['--run', f'{name}={ROOT}/results/target3/{folder}/run-2/summary.json'])
    command.extend(['--output', str(ROOT / 'results/target3/comparison-run-2.json')])
    with (runtime / 'comparison-run-2-cli.txt').open('w', encoding='utf-8') as handle:
        subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT, check=True)
    captures = {
        'pip-freeze-run-2.txt': [sys.executable, '-m', 'pip', 'freeze'],
        'nvidia-smi-run-2.txt': ['nvidia-smi'],
        'nvcc-version-run-2.txt': ['nvcc', '--version'],
    }
    for name, command in captures.items():
        with (runtime / name).open('w', encoding='utf-8') as handle:
            subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT, check=True)
    (runtime / 'os-release-run-2.txt').write_text(Path('/etc/os-release').read_text(), encoding='utf-8')
    (runtime / 'python-version-run-2.txt').write_text(sys.version + '\n', encoding='utf-8')
    log_root = Path('/tmp/ray/session_latest/logs/serve')
    if log_root.is_dir():
        target = runtime / 'logs/ray-serve-run-2'
        target.mkdir(parents=True, exist_ok=True)
        for log in log_root.glob('*.log'):
            shutil.copy2(log, target / log.name)
    archive = ROOT.parent / 'HW3-姜佳岩-新实验结果.zip'
    excluded = {'.venv', '__pycache__', '.git', 'node_modules'}
    count = 0
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as handle:
        readme = ROOT / 'README.md'
        if readme.exists():
            handle.write(readme, ROOT.name + '/README.md')
        for name in ('src', 'results', 'runtime'):
            for path in sorted((ROOT / name).rglob('*')):
                if not path.is_file() or excluded.intersection(path.parts) or path.suffix == '.pyc':
                    continue
                handle.write(path, path.relative_to(ROOT.parent).as_posix())
                count += 1
    print('五种配置均完成 2048 条测量及 64 条预热；C 严格亲和核验通过。')
    print('已生成新一轮 comparison-run-2.json。')
    print('导出文件：', archive)
    print('文件数：', count + 1, '；压缩包字节数：', archive.stat().st_size)


if __name__ == '__main__':
    main()
