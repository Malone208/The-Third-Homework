import unittest
from policy import rank_replicas


class PolicyTests(unittest.TestCase):
    def test_low_load_keeps_affinity(self):
        self.assertEqual(rank_replicas(['a','b','c','d'], 'a',
                         {'a':2,'b':0,'c':1,'d':0}, 16), [['a']])

    def test_hot_primary_spills_to_known_lowest_load(self):
        ranks = rank_replicas(['a','b','c','d'], 'a',
                              {'a':14,'b':4,'c':1,'d':None}, 16)
        self.assertEqual(ranks[0], ['c'])
        self.assertEqual(ranks[-1], ['a'])
        self.assertEqual({i for rank in ranks for i in rank}, {'a','b','c','d'})

    def test_stale_load_is_not_treated_as_idle(self):
        self.assertEqual(rank_replicas(['a','b'], 'a', {'a':16,'b':None}, 16), [['a']])
        self.assertEqual(rank_replicas(['a','b'], 'a', {'a':None,'b':0}, 16), [['a']])

    def test_saturated_cluster_keeps_primary_for_framework_retry(self):
        self.assertEqual(rank_replicas(['a','b'], 'a', {'a':16,'b':16}, 16), [['a']])

    def test_small_difference_does_not_break_affinity(self):
        self.assertEqual(rank_replicas(['a','b'], 'a', {'a':12,'b':11}, 16), [['a']])


if __name__ == '__main__':
    unittest.main()
