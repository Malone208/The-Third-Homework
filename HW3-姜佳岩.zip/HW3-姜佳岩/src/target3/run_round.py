"""Redeploy -> prove placement -> flush all four caches -> official replay."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import importlib.metadata
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def flush(url):
    with urlopen(Request(url + '/flush_cache', data=b'', method='POST'), timeout=60) as response:
        body = response.read().decode()
        if response.status != 200 or 'Cache flushed' not in body:
            raise RuntimeError(f'Cache flush failed: {url} {body}')
        return {'backend': url, 'status': response.status, 'body': body}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--group', choices=['A', 'B', 'C', 'D'], required=True)
    parser.add_argument('--limit', type=int, help='A must be 5; B candidates are 16 and 32')
    parser.add_argument('--run-name', default='run-1')
    args = parser.parse_args()
    if not re.fullmatch(r'run-[1-9][0-9]*', args.run_name):
        parser.error('Use run-1, run-2, ...')
    if args.group == 'A':
        limit = 5
        if args.limit not in (None, 5):
            parser.error('A uses the default value 5')
    elif args.group == 'B':
        limit = args.limit
        if limit not in (16, 32):
            parser.error('This experiment tests B candidates 16 and 32')
    else:
        selection_folder = ROOT / 'results/target3/B_candidates'
        selection_path = selection_folder / ('selection.json' if args.run_name == 'run-1'
                                             else f'selection-{args.run_name}.json')
        if not selection_path.exists() and args.run_name != 'run-1':
            if any((selection_folder / f'candidate-{n}' / args.run_name / 'summary.json').exists()
                   for n in (16, 32)):
                raise RuntimeError('Select B for this run first: python src/target3/select_b.py ' + args.run_name)
            # C/D-only repair on the same host may reuse the original B choice.
            selection_path = selection_folder / 'selection.json'
        choice = json.loads(selection_path.read_text('utf-8'))
        limit = choice['selected_limit']
        if args.limit not in (None, limit):
            parser.error('C and D must use the selected B value')
    group_path = {'A': 'A_default', 'B': f'B_candidates/candidate-{limit}',
                  'C': 'C_affinity', 'D': 'D_improved'}[args.group]
    output = ROOT / 'results/target3' / group_path / args.run_name
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f'Results already exist: {output}; use a new run name')
    state = json.loads((ROOT / 'runtime/cluster.json').read_text('utf-8'))
    if not state['ready']:
        raise RuntimeError('start_services.py must remain running')

    import ray
    from ray import serve
    from ray.serve.config import RequestRouterConfig
    from forwarder import SGLangForwarder
    from route_preflight import run_preflight, verify_strict_affinity

    if importlib.metadata.version('ray') != '2.56.0':
        raise RuntimeError('Ray 2.56.0 required')
    ray.init(address=state['address'], namespace='hw3', log_to_driver=True)
    try:
        live = [n for n in ray.nodes() if n['Alive']]
        if len(live) != 5 or not all(nid in {n['NodeID'] for n in live}
                                      for nid in state['backend_by_node']):
            raise RuntimeError('All five original nodes must be active')
        serve.start(proxy_location='HeadOnly', http_options={'host': '127.0.0.1', 'port': 8000})
        for old_app in list(serve.status().applications):
            if old_app == 'hw3-routing' or old_app.startswith('hw3-routing-'):
                serve.delete(old_app, _blocking=True)
        # A distinct DeploymentID prevents the proxy's cached handle/router
        # from retaining the previous round's routing class.
        app_name = f'hw3-routing-{args.group}-{limit}-{args.run_name}'
        router_name = 'p2c'
        config = RequestRouterConfig()
        if args.group == 'C':
            router_name = 'consistent_hash'
            config = RequestRouterConfig(
                request_router_class='ray.serve.experimental.consistent_hash_router:ConsistentHashRouter',
                request_router_kwargs={'num_virtual_nodes': 100, 'num_fallback_replicas': 0})
        elif args.group == 'D':
            router_name = 'affinity_load'
            config = RequestRouterConfig(
                request_router_class='improved_router:AffinityLoadRouter',
                request_router_kwargs={'num_virtual_nodes': 100, 'num_fallback_replicas': 0,
                                       'load_fraction': 0.75, 'load_gap': 2})
        output.mkdir(parents=True, exist_ok=True)
        topology_dir = output / 'replicas'
        app = SGLangForwarder.options(
            num_replicas=4, max_ongoing_requests=limit,
            ray_actor_options={'num_cpus': 1, 'resources': {'hw3_worker': 1}},
            request_router_config=config,
        ).bind(state['backend_by_node'], str(topology_dir))
        serve.run(app, name=app_name, route_prefix='/')
        replicas = [json.loads(p.read_text('utf-8')) for p in topology_dir.glob('*.json')]
        for field in ('replica_id', 'ray_node_id', 'backend'):
            if len({r[field] for r in replicas}) != 4:
                raise RuntimeError('Four distinct replicas/nodes/backends required: ' + field)
        run_preflight(output, args.group)
        with ThreadPoolExecutor(max_workers=4) as executor:
            flushes = list(executor.map(flush, state['backend_by_node'].values()))
        (output / 'deployment.json').write_text(json.dumps({
            'group': args.group, 'limit': limit, 'router_name': router_name,
            'app_name': app_name, 'request_router_class': config.request_router_class,
            'nodes': live, 'replicas': replicas, 'flushes': flushes,
            'versions': state['versions'], 'sglang_options': state['sglang_options'],
            'router_kwargs': config.request_router_kwargs,
        }, indent=2), encoding='utf-8')
        command = [sys.executable, str(HERE / 'course/run_workload.py'), '--policy', 'serve',
                   '--run-name', args.group + '_' + str(limit) + '_' + args.run_name,
                   '--router-name', router_name, '--max-ongoing-requests', str(limit),
                   '--base-url', 'http://127.0.0.1:8000',
                   '--workload', str(HERE / 'course/mooncake_prefix_workload_v2_seed2026.jsonl'),
                   '--max-in-flight', '2048', '--timeout', '300', '--output-dir', str(output),
                   '--metadata', 'gpu=' + state['gpu_name'],
                   '--metadata', 'sglang=0.5.14', '--metadata', 'ray=2.56.0']
        subprocess.run(command, check=True)
        if args.group == 'C':
            verify_strict_affinity(output)
        print('Round complete. Original CSV/JSON files:', output)
    finally:
        ray.shutdown()


if __name__ == '__main__':
    main()
