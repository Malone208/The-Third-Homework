"""Read-only audit of the submitted formal run-2; no GPU or third-party packages."""
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUNS = {'A': 'A_default', 'B16': 'B_candidates/candidate-16',
        'B32': 'B_candidates/candidate-32', 'C': 'C_affinity', 'D': 'D_improved'}
SHA = 'f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03'


def audit():
    workload = ROOT / 'src/target3/course/mooncake_prefix_workload_v2_seed2026.jsonl'
    assert hashlib.sha256(workload.read_bytes()).hexdigest() == SHA
    work = {str(x['request_id']): x for x in map(json.loads, workload.read_text('utf-8').splitlines())}
    nodes_ref = versions_ref = options_ref = None
    result = {'workload_sha256': SHA, 'formal_run': 'run-2', 'runs': {}}
    for name, folder in RUNS.items():
        p = ROOT / 'results/target3' / folder / 'run-2'
        s = json.loads((p / 'summary.json').read_text('utf-8'))
        d = json.loads((p / 'deployment.json').read_text('utf-8'))
        with (p / 'requests.csv').open(encoding='utf-8', newline='') as f:
            rows = list(csv.DictReader(f))
        with (p / 'warmups.csv').open(encoding='utf-8', newline='') as f:
            warm = list(csv.DictReader(f))
        assert len(rows) == s['successful'] == s['requests'] == 2048, name
        assert len(warm) == s['warmup_successful'] == 64, name
        assert not any(s[k] for k in ('failed', 'incomplete', 'warmup_failed', 'warmup_incomplete', 'validation_errors'))
        assert {r['request_id'] for r in rows + warm} == set(work)
        assert len({r['request_id'] for r in rows + warm}) == len(rows + warm)
        mapping = {r['replica_id']: (r['ray_node_id'], r['backend']) for r in d['replicas']}
        assert len(mapping) == len({v[0] for v in mapping.values()}) == len({v[1] for v in mapping.values()}) == 4
        nodes = {n['NodeID'] for n in d['nodes'] if n['Alive']}
        assert len(nodes) == 5
        if nodes_ref is None:
            nodes_ref, versions_ref, options_ref = nodes, d['versions'], d['sglang_options']
        assert (nodes, d['versions'], d['sglang_options']) == (nodes_ref, versions_ref, options_ref)
        assert len(d['flushes']) == 4 and all(x['status'] == 200 for x in d['flushes'])
        assert json.loads((p / 'routing_preflight.json').read_text('utf-8'))['passed']
        family = defaultdict(set)
        for r in rows + warm:
            w = work[r['request_id']]
            assert r['prefix_family'] == w['prefix_family']
            assert r['status_code'] == '200' and not r['error']
            assert int(r['input_tokens']) == int(r['prompt_tokens']) == int(w['input_tokens'])
            assert int(r['output_tokens']) == int(r['requested_output_tokens']) == int(w['output_tokens'])
            assert 0 <= int(r['cached_tokens']) <= int(r['prompt_tokens'])
            assert mapping[r['replica_id']] == (r['ray_node_id'], r['backend'])
            if r['phase'] == 'measured':
                assert math.isclose(float(r['planned_send_s']), w['arrival_offset_s'], abs_tol=1e-9)
            family[r['prefix_family']].add(r['backend'])
        prompt = sum(int(r['prompt_tokens']) for r in rows)
        cached = sum(int(r['cached_tokens']) for r in rows)
        assert prompt == s['prompt_tokens_total'] and cached == s['cached_tokens_total']
        assert prompt-cached == s['computed_prefill_tokens_total']
        assert math.isclose(cached/prompt, s['cache_hit_rate'])
        assert math.isclose(s['successful']/s['elapsed_s'], s['throughput_rps'])
        assert Counter(r['backend'] for r in rows) == s['backend_distribution']
        for k in ('ttft_s', 'latency_s', 'client_queue_s', 'dispatch_lag_s'):
            values = sorted(float(r[k]) for r in rows)
            assert math.isclose(values[math.ceil(.95*len(values))-1], s[k]['p95'])
        if name == 'C':
            assert len(family) == 64 and all(len(v) == 1 for v in family.values())
            assert json.loads((p / 'strict_affinity_check.json').read_text('utf-8'))['passed']
        result['runs'][name] = {'passed': True, 'measured': len(rows), 'warmups': len(warm),
                               'families_using_multiple_backends': sum(len(v)>1 for v in family.values())}
    choice = json.loads((ROOT / 'results/target3/B_candidates/selection-run-2.json').read_text('utf-8'))
    candidates = choice['candidates']
    best = max(c['throughput_rps'] for c in candidates)
    eligible = [c for c in candidates if c['throughput_rps'] >= .95 * best]
    chosen = min(eligible, key=lambda c: (c['ttft_p95_s'], c['latency_p95_s'], c['limit']))
    assert chosen['limit'] == choice['selected_limit'] == 32
    result['passed'] = True
    return result


if __name__ == '__main__':
    print(json.dumps(audit(), ensure_ascii=False, indent=2))
