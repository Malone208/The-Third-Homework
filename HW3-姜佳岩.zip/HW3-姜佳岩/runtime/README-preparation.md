# HW3-姜佳岩

## 当前进度

2026-10-07：已准备课程回放脚本、四后端/五逻辑节点启动脚本和 A/B/C/D 路由配置。
当前尚未租用四卡实例，未生成目标三的正式实验结果或报告。
本地路由规则测试与语法检查不能替代服务器上的正式实验。
上一轮目标一的代码和真实 run-1 结果保留于 `src/target1/` 与 `results/target1/`。

## 硬件与环境

需要同一物理主机上一个实例提供四张独立 NVIDIA GPU，建议先核对实例的四卡总时价和驱动信息。
预期预算约 50 元；实际费用取决于实例单价与开机时长。
每张卡运行一个 Qwen/Qwen3-0.6B；Ray 不承载模型权重，仅转发请求。
Linux、Python 3.12、SGLang 0.5.14、Ray Serve 2.56.0。
SGLang 0.5.14 的依赖使用 CUDA 13 相关组件；租用前须核对驱动与 CUDA 13 兼容，不能只根据镜像名称判断。NVIDIA 的 CUDA 13.x 最低驱动主版本要求为 580，具体组件还需要满足其兼容条件。
运行时的实际 GPU、Torch、CUDA 和模型设置记录在 `runtime/cluster.json` 与每轮 `deployment.json`。

进入上传并解压后的项目目录，安装依赖：

```bash
python --version
nvidia-smi
nvcc --version
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r src/target3/requirements.txt
python -c "import torch; print(torch.__version__, torch.version.cuda, torch.cuda.is_available(), torch.cuda.device_count())"
```

若镜像缺少 venv、CUDA Toolkit 或 Python 开发头文件，先补齐环境，再启动服务。
环境具体安装命令待选定服务器镜像后确定。`.venv/`、模型、安装包和缓存均不纳入作业提交。

## 固定负载与来源

课程数据仓库固定提交：`9651052e597def42d5ee22548d904d8927365b20`。
`src/target3/course/` 包含发布的回放、校验、汇总脚本和原始 README。
正式负载必须具有如下 SHA256：

```text
f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03
```

下载与校验：

```bash
python src/target3/download_workload.py
python src/target3/course/validate_workload.py src/target3/course/mooncake_prefix_workload_v2_seed2026.jsonl
```

必须显示 64 个前缀族、64 条预热、2048 条测量请求。所有配置使用同一个文件，不更改请求、顺序或到达时间。

## 启动服务

在服务器终端一：

```bash
source .venv/bin/activate
python src/target3/start_services.py
```

该脚本先获取模型，再启动四个相同配置的 SGLang 后端，端口 31000 至 31003。
已有本地模型可传 `--model-path /本地/Qwen3-0.6B目录`。
默认使用实例分配的 `CUDA_VISIBLE_DEVICES`；确需手动指定时传四个实际分配的 ID，如 `--gpu-ids 0,1,2,3`。
每个后端：context-length=4096，mem-fraction-static=0.6，stream-interval=1，Radix Cache 开启。

随后用 `ray.cluster_utils.Cluster` 建立一个 head 和四个 worker。每个 worker 仅有一单位 `hw3_worker` 自定义资源，每个 Serve Replica 需要一单位该资源，因此四个副本各占一个 worker，不能调度到 head 或同一个 worker。
每个 worker 对应一个固定 SGLang 后端。Ray 节点 `num_gpus=0` 是因为模型进程在 Ray 外直接使用 GPU，不代表模型使用 CPU。
保留终端一运行。不要将这四个服务分别放在四台机器。

## 运行五种配置

在服务器终端二进入同一项目目录，激活环境后运行：

```bash
source .venv/bin/activate
python src/target3/run_round.py --group A
python src/target3/run_round.py --group B --limit 16
python src/target3/run_round.py --group B --limit 32
python src/target3/select_b.py
python src/target3/run_round.py --group C
python src/target3/run_round.py --group D
```

只有上一条命令成功完成后才运行下一条；发生错误时检查日志和保留的文件，不将失败轮计入完成结果。
每轮删除旧 Serve 应用，再部署当前配置，检查四个副本所在节点，清空四个后端缓存，最后调用课程回放器。
回放器先完成 64 条预热，再发送 2048 条测量，预热不计入主表。
同一个 Ray Serve HTTP 入口为 `http://127.0.0.1:8000/generate`。
请求体与三个课程请求头转发到 SGLang，SSE 字节流原样返回，响应包含三个课程路由标识头。

A 使用默认 P2C，max_ongoing_requests=5。B 候选为 16 和 32。
B 的预先规定选择规则：吞吐量距离较高者不超过 5% 的候选中，选择 TTFT p95 较低者；依次以端到端 p95 与更小参数打破平局。
选择记录在 `results/target3/B_candidates/selection.json`，C 和 D 自动使用该值。
C 使用 Ray 2.56.0 原生 ConsistentHashRouter，100 个虚拟节点，num_fallback_replicas=0。
D 继承同一个路由器：主副本队列估计达到容量的 75%，且比另一个已知队列至少多 2 个请求、对方未满时，转向已知负载较低的副本；否则保留亲和。
D 使用 Ray 当前队列缓存和当前 session_id；未知/过期队列值不视作空闲，不读取未来请求。
队列估计可能滞后，溢出路由可能降低缓存命中率。这些代价要根据实际数据分析，不能预先断言 D 所有指标最优。
每轮重新部署会产生新 Replica ID；一致哈希的具体前缀映射也可能变化，报告需如实说明。

## 原始结果与汇总

每种配置的 `run-1/` 保存课程回放器生成的 `config.json`、`warmups.csv`、`requests.csv`、`summary.json`。
额外保存 `deployment.json` 与 `replicas/`，证明节点、副本、后端映射和清空缓存情况。

```bash
python src/target3/course/compare_runs.py --baseline A \
  --run A=results/target3/A_default/run-1/summary.json \
  --run B1=results/target3/B_candidates/candidate-16/run-1/summary.json \
  --run B2=results/target3/B_candidates/candidate-32/run-1/summary.json \
  --run C=results/target3/C_affinity/run-1/summary.json \
  --run D=results/target3/D_improved/run-1/summary.json \
  --output results/target3/comparison.json
```

每轮必须 successful=2048、failed=0、incomplete=0，预热成功 64 条、validation_errors 为空，副本/节点/后端分布均包含四项。
报告主表从这些真实汇总读取成功率、吞吐量、缓存命中率、Prefill token、TTFT p95、端到端 p95、四后端分布。
分阶段统计保留在 summary.json，client_queue 与 dispatch_lag 用于检查客户端瓶颈。
重复实验用 `--run-name run-2` 等新目录；重测 B 并重新选参数时需另建实验系列、保留原 selection.json，不覆盖原记录。

## 本地测试与结束实验

```bash
python -m unittest discover -s src/target3 -p test_policy.py -v
```

这是离线路由规则检查；五节点、多副本流式转发和正式结果仍需在四卡服务器验收。
保存并下载结果后，在终端一 Ctrl+C 结束本脚本启动的服务，然后在租用平台关机结束算力计费。
关闭终端或只停止 Python 进程不等于平台关机。

## 提交材料

正式实验完成后生成 report.pdf 和 AI 使用说明情况（第三次挑战）.pdf，再打包 HW3-姜佳岩.zip。
作业感受第（2）、（3）问由本人提供文字；补充内容与原文分开保留，不自动替换原回答。
此时仍是准备目录，不是已完成的作业提交包。
